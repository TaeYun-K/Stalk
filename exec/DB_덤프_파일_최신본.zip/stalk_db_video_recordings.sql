-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: i13e205.p.ssafy.io    Database: stalk_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `video_recordings`
--

DROP TABLE IF EXISTS `video_recordings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_recordings` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '녹화 ID',
  `consultation_id` bigint NOT NULL COMMENT '상담 고유 ID (FK)',
  `recording_id` varchar(128) NOT NULL COMMENT 'OpenVidu 녹화 ID',
  `session_id` varchar(128) NOT NULL COMMENT 'WebRTC 세션 ID',
  `url` text COMMENT '녹화 영상 URL',
  `start_time` datetime DEFAULT NULL COMMENT '녹화 시작 시각',
  `end_time` datetime DEFAULT NULL COMMENT '녹화 종료 시각',
  `status` varchar(20) DEFAULT NULL COMMENT '녹화 상태 (started, stopped 등)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '생성 시각',
  PRIMARY KEY (`id`),
  KEY `fk_video_recording_to_consultation` (`consultation_id`),
  CONSTRAINT `fk_video_recording_to_consultation` FOREIGN KEY (`consultation_id`) REFERENCES `consultation_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  8:55:01
