-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: i13e205.p.ssafy.io    Database: stalk_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `consultation_sessions_backup`
--

DROP TABLE IF EXISTS `consultation_sessions_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultation_sessions_backup` (
  `id` bigint NOT NULL DEFAULT '0' COMMENT '상담 내역 고유 ID',
  `user_id` bigint NOT NULL COMMENT '상담 요청자 (일반 사용자)',
  `advisor_id` bigint NOT NULL COMMENT '공통 사용자 ID (전문가)',
  `date` date NOT NULL COMMENT '상담 날짜',
  `start_time` time NOT NULL COMMENT '상담 시작 시간',
  `end_time` time NOT NULL COMMENT '상담 종료 시간',
  `request_message` text COMMENT '상담 요청 내용',
  `sessionId` varchar(255) DEFAULT NULL COMMENT 'WebRTC 화상 회의 방 id',
  `video_url` varchar(255) DEFAULT NULL COMMENT '녹화 영상 저장 위치 (파일 경로 또는 S3/클라우드 URL 등)',
  `status` enum('PENDING','APPROVED','CANCELED') DEFAULT 'PENDING' COMMENT '처리 상태',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '요청 생성 시각',
  `canceled_by` bigint DEFAULT NULL COMMENT '취소한 사용자 ID',
  `cancel_reason` varchar(50) DEFAULT NULL COMMENT '취소 사유 (enum)',
  `cancel_memo` text COMMENT '취소 상세 사유',
  `canceled_at` timestamp NULL DEFAULT NULL COMMENT '취소 시각'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  8:55:00
