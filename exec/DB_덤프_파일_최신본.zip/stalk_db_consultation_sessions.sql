-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: i13e205.p.ssafy.io    Database: stalk_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `consultation_sessions`
--

DROP TABLE IF EXISTS `consultation_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultation_sessions` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '상담 내역 고유 ID',
  `user_id` bigint NOT NULL COMMENT '상담 요청자 (일반 사용자)',
  `advisor_id` bigint NOT NULL COMMENT '공통 사용자 ID (전문가)',
  `date` date NOT NULL COMMENT '상담 날짜',
  `start_time` time NOT NULL COMMENT '상담 시작 시간',
  `end_time` time NOT NULL COMMENT '상담 종료 시간',
  `request_message` text COMMENT '상담 요청 내용',
  `session_id` varchar(255) DEFAULT NULL COMMENT 'WebRTC 화상 회의 방 ID',
  `video_url` varchar(255) DEFAULT NULL COMMENT '녹화 영상 저장 위치 (파일 경로 또는 S3/클라우드 URL 등)',
  `status` enum('PENDING','APPROVED','CANCELED') DEFAULT 'PENDING' COMMENT '처리 상태',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '요청 생성 시각',
  `canceled_by` bigint DEFAULT NULL COMMENT '취소한 사용자 ID',
  `cancel_reason` varchar(50) DEFAULT NULL COMMENT '취소 사유 (enum)',
  `cancel_memo` text COMMENT '취소 상세 사유',
  `canceled_at` timestamp NULL DEFAULT NULL COMMENT '취소 시각',
  `payment_key` varchar(200) DEFAULT NULL COMMENT '토스페이먼츠 결제 키',
  `order_id` varchar(100) DEFAULT NULL COMMENT '주문번호 (CONSULT_YYYYMMDD_HHMMSS_USERID_ADVISORID)',
  `amount` int DEFAULT NULL COMMENT '결제 금액',
  `payment_status` enum('PENDING','PAID','CANCELLED','FAILED') DEFAULT 'PENDING' COMMENT '결제 상태',
  `payment_method` varchar(50) DEFAULT NULL COMMENT '결제 수단 (카드, 간편결제, 계좌이체)',
  `paid_at` datetime DEFAULT NULL COMMENT '결제 완료 시간',
  `payment_cancelled_at` datetime DEFAULT NULL COMMENT '결제 취소 시간',
  `card_company` varchar(50) DEFAULT NULL COMMENT '카드사 정보',
  `receipt_url` text COMMENT '영수증 URL',
  `failure_code` varchar(50) DEFAULT NULL COMMENT '결제 실패 코드',
  `failure_reason` varchar(200) DEFAULT NULL COMMENT '결제 실패 사유',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_advisor_datetime` (`advisor_id`,`date`,`start_time`),
  UNIQUE KEY `order_id` (`order_id`),
  KEY `FK_users_TO_consultation_sessions_1` (`user_id`),
  KEY `fk_canceled_by` (`canceled_by`),
  KEY `idx_payment_key` (`payment_key`),
  CONSTRAINT `FK_advisor_TO_consultation_sessions_1` FOREIGN KEY (`advisor_id`) REFERENCES `advisor` (`advisor_id`),
  CONSTRAINT `fk_canceled_by` FOREIGN KEY (`canceled_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FK_users_TO_consultation_sessions_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  8:55:05
