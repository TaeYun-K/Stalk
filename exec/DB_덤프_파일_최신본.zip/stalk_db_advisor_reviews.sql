-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: i13e205.p.ssafy.io    Database: stalk_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `advisor_reviews`
--

DROP TABLE IF EXISTS `advisor_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `advisor_reviews` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '리뷰 고유 ID',
  `user_id` bigint NOT NULL COMMENT '리뷰 작성자(클라이언트) ID',
  `advisor_id` bigint NOT NULL COMMENT '리뷰 대상 전문가 ID',
  `rating` tinyint DEFAULT '5' COMMENT '별점 (1~5점)',
  `content` text COMMENT '리뷰 내용',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '리뷰 작성 날짜 및 시간',
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '리뷰 삭제 여부',
  PRIMARY KEY (`id`,`user_id`,`advisor_id`),
  KEY `FK_users_TO_advisor_reviews_1` (`user_id`),
  KEY `idx_advisor_reviews_advisor_id_deleted` (`advisor_id`,`is_deleted`),
  KEY `idx_advisor_reviews_rating_deleted` (`rating`,`is_deleted`),
  CONSTRAINT `FK_advisor_TO_advisor_reviews_1` FOREIGN KEY (`advisor_id`) REFERENCES `advisor` (`advisor_id`),
  CONSTRAINT `FK_users_TO_advisor_reviews_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  8:55:02
